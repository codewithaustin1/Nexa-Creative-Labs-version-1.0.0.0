---
title: "Example Post"
date: 2025-07-17
---

Welcome to your very first blog post powered by Decap CMS!